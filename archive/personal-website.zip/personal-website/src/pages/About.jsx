import SEO from '@/components/utility/SEO'
import { Link } from 'react-router-dom'

const skills = [
  { category: 'Frontend',  items: ['React', 'TypeScript', 'Tailwind CSS', 'Next.js', 'Vite'] },
  { category: 'Backend',   items: ['Node.js', 'Express', 'PostgreSQL', 'Redis', 'REST / GraphQL'] },
  { category: 'DevOps',    items: ['AWS (S3, Lambda, CloudFront)', 'Docker', 'GitHub Actions', 'Terraform'] },
  { category: 'Tools',     items: ['Git', 'Figma', 'VS Code', 'Postman', 'Linear'] },
]

const timeline = [
  {
    year: '2024',
    role: 'Senior Frontend Engineer',
    company: 'Acme Corp',
    desc: 'Led the redesign of the core product UI, improving Lighthouse performance scores from 62 to 97.',
  },
  {
    year: '2022',
    role: 'Full-Stack Developer',
    company: 'Startup Inc.',
    desc: 'Built and launched three SaaS products from 0 to paying customers, handling both frontend and backend.',
  },
  {
    year: '2020',
    role: 'Junior Developer',
    company: 'Agency XYZ',
    desc: 'Delivered responsive marketing sites and e-commerce experiences for a portfolio of 20+ clients.',
  },
  {
    year: '2019',
    role: 'B.Sc. Computer Science',
    company: 'State University',
    desc: 'Graduated with honors. Thesis on optimizing graph traversal algorithms.',
  },
]

export default function About() {
  return (
    <>
      <SEO
        title="About"
        description="Learn more about Your Name — a full-stack developer with 5+ years of experience building web products."
        url="https://yourwebsite.com/about"
      />

      {/* Hero */}
      <section className="pt-32 pb-16 max-w-6xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="animate-fade-up">
            <p className="text-xs font-mono text-brand-500 uppercase tracking-widest mb-3">About Me</p>
            <h1 className="font-display text-4xl md:text-5xl font-bold text-surface-900 mb-6 leading-tight">
              Developer by trade,<br />
              <span className="text-brand-600">builder by nature.</span>
            </h1>
            <div className="space-y-4 text-surface-600 leading-relaxed">
              <p>
                I'm a full-stack developer based in [Your City] with 5+ years of experience creating
                web applications that are fast, accessible, and genuinely enjoyable to use.
              </p>
              <p>
                My expertise spans the full stack — from crafting pixel-perfect React interfaces to
                architecting scalable backend systems on AWS. I care deeply about performance, clean
                code, and great developer experience.
              </p>
              <p>
                Outside of work, I write about web development, contribute to open source, and
                occasionally write on my blog about things I've learned the hard way.
              </p>
            </div>
            <div className="flex gap-4 mt-8">
              <Link to="/contact" className="btn-primary">Work With Me</Link>
              <a
                href="/resume.pdf"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-secondary"
              >
                Download CV
              </a>
            </div>
          </div>

          {/* Avatar placeholder */}
          <div className="flex justify-center md:justify-end">
            <div className="relative w-64 h-64 md:w-80 md:h-80">
              <div className="w-full h-full rounded-2xl bg-gradient-to-br from-brand-200 to-brand-400 flex items-center justify-center">
                <span className="font-display text-8xl font-bold text-white/60">YN</span>
              </div>
              {/* Decorative ring */}
              <div className="absolute -inset-3 border-2 border-brand-200 rounded-2xl -z-10 rotate-3" />
            </div>
          </div>
        </div>
      </section>

      {/* Skills */}
      <section className="py-16 bg-surface-50 border-y border-surface-200">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <p className="text-xs font-mono text-brand-500 uppercase tracking-widest mb-2">Toolkit</p>
          <h2 className="section-heading mb-10">Skills & Technologies</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
            {skills.map(({ category, items }) => (
              <div key={category} className="card p-5">
                <h3 className="font-mono text-xs font-semibold text-brand-600 uppercase tracking-wider mb-3">
                  {category}
                </h3>
                <ul className="space-y-2">
                  {items.map(item => (
                    <li key={item} className="flex items-center gap-2 text-sm text-surface-700">
                      <span className="w-1.5 h-1.5 rounded-full bg-brand-400 flex-shrink-0" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <p className="text-xs font-mono text-brand-500 uppercase tracking-widest mb-2">History</p>
          <h2 className="section-heading mb-10">Experience & Education</h2>
          <div className="relative">
            {/* Vertical line */}
            <div className="absolute left-[7px] top-2 bottom-2 w-px bg-surface-200 hidden sm:block" />
            <div className="space-y-8">
              {timeline.map((item, i) => (
                <div key={i} className="sm:pl-10 relative">
                  {/* Dot */}
                  <div className="hidden sm:block absolute left-0 top-1.5 w-3.5 h-3.5 rounded-full bg-brand-500 border-2 border-white shadow" />
                  <div className="flex flex-wrap items-center gap-3 mb-1">
                    <span className="font-mono text-xs text-brand-500 bg-brand-50 px-2 py-0.5 rounded">
                      {item.year}
                    </span>
                    <h3 className="font-semibold text-surface-900">{item.role}</h3>
                    <span className="text-surface-400 text-sm">@ {item.company}</span>
                  </div>
                  <p className="text-sm text-surface-600 leading-relaxed">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
